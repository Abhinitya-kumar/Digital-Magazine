const searchInput = document.getElementById("search");
const cards = document.querySelectorAll(".card");

searchInput.addEventListener("keyup", function () {
    const searchValue = this.value.toLowerCase();

    cards.forEach(card => {
        const title = card.querySelector("h3").innerText.toLowerCase();
        const desc = card.querySelector("p").innerText.toLowerCase();

        if (title.includes(searchValue) || desc.includes(searchValue)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
});

  // Subscribe logic
  function handleSubscribe() {
    const emailInput = document.querySelector(
      ".subscribe-modal input, .modal input, #subscribeEmail"
    );
  
    if (!emailInput) {
      alert("Email input not found!");
      return;
    }
  
    const email = emailInput.value.trim();
  
    if (!email || !email.includes("@")) {
      alert("Please enter a valid email address");
      return;
    }
   // Save locally (optional)
    let list = JSON.parse(localStorage.getItem("subscribers") || "[]");
    list.push(email);
    localStorage.setItem("subscribers", JSON.stringify(list));
  
    alert("Subscribed successfully 🎉");
  
    emailInput.value = "";
    closeSubscribe();
  }





  function openSubscribe() {
    const modal = document.querySelector(".subscribe-modal, .modal, #subscribeModal");
    if (modal) modal.style.display = "flex";
  }
  
  function closeSubscribe() {
    const modal = document.querySelector(".subscribe-modal, .modal, #subscribeModal");
    if (modal) modal.style.display = "none";
  }
  
  function handleSubscribe() {
    const emailInput = document.querySelector(
      ".subscribe-modal input, .modal input, #subscribeModal input"
    );
  
    if (!emailInput) {
      alert("Email field not found");
      return;
    }
  
    const email = emailInput.value.trim();
  
    if (!email || !email.includes("@")) {
      alert("Please enter a valid email address");
      return;
    }
  
    // Save locally
    let subscribers = JSON.parse(localStorage.getItem("subscribers") || "[]");
    subscribers.push(email);
    localStorage.setItem("subscribers", JSON.stringify(subscribers));
  
    alert("Subscribed successfully 🎉");
  
    emailInput.value = "";
    closeSubscribe();
  }
  